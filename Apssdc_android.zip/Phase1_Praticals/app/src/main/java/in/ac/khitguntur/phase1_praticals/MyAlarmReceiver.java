package in.ac.khitguntur.phase1_praticals;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;

public class MyAlarmReceiver extends BroadcastReceiver
{
    public static final String CUSTOM_BROADCAST="in.ac.khitguntur.phase1_praticals.CUSTOM_BROAD";


    @Override
    public void onReceive(Context context, Intent intent)
    {
        // TODO: This method is called when the BroadcastReceiver is receiving

        NotificationManager notificationManager= (NotificationManager) context
                .getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder builder=new NotificationCompat.Builder(context);
        builder.setSmallIcon(R.drawable.iconsss);
        builder.setContentTitle("Please WakeUP");
        builder.setContentText("Hello This Is Reminder for wake up");
        builder.setAutoCancel(true);
        builder.setDefaults(Notification.DEFAULT_ALL);
        notificationManager.notify(9,builder.build());

    }
}
