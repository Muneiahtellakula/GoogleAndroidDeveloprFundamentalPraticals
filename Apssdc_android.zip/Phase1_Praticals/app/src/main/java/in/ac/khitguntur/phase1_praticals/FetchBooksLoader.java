package in.ac.khitguntur.phase1_praticals;


import android.content.Context;
import android.net.Uri;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Hi on 27-07-2017.
 */


public class FetchBooksLoader
        extends AsyncTaskLoader<String>

{
    String bookName;
  //  public static final String URL="https://www.imdb.com/title/tt2353357/?";
    public static final String URL = "https://www.googleapis.com/books/v1/volumes?";
    public static final String QUERY_PARAM = "q";
    public static final String MAX_RESULTS = "maxResults";
    public static final String PRINT_TYPE = "printType";

    public FetchBooksLoader(Context context, String bookName)
    {
        super(context);
        this.bookName = bookName;
    }

    @Override
    public String loadInBackground()
    {
       Uri builtUri = Uri.parse(URL).buildUpon()
                .appendQueryParameter(QUERY_PARAM,bookName)
                .appendQueryParameter(MAX_RESULTS,"10")
                .appendQueryParameter(PRINT_TYPE,"books")
                .build();
        //lets get URL (uniform resource Locator)
        //This will actually run on a browser
        try {
            URL url = new URL(builtUri.toString());
            //open a Connection to Internet
            HttpURLConnection httpURLConnection
                    = (HttpURLConnection)url.openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.connect();
            //now Read the Response
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader =
                    new BufferedReader(new InputStreamReader(inputStream));
            StringBuffer sb = new StringBuffer();
            String line = "";
            while((line=bufferedReader.readLine())!=null)
            {
                sb.append(line+"\n");
            }
            String JSONresponse = sb.toString();
            return JSONresponse;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onStartLoading()
    {
        forceLoad();
    }
}
