package in.ac.khitguntur.phase1_praticals;

import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class BroadCastReceverActivity extends AppCompatActivity {
    public static final String CUSTOM_BROADCAT=
            "in.ac.khitguntur.phase1_praticals.CUSTOM_BROADCAST";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_broad_cast_recever);
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(new MyBroadCasrReceiver(),
                        new IntentFilter(CUSTOM_BROADCAT));

    }

    public void openCustome(View view)
    {
        Intent intent=new Intent(CUSTOM_BROADCAT);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(new MyBroadCasrReceiver());

    }
}
