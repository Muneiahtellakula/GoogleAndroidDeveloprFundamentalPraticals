package in.ac.khitguntur.phase1_praticals;

import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class Tab_Nav extends AppCompatActivity
{
    TabLayout tabLayout;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab__nav);
        tabLayout=findViewById(R.id.tab);
        viewPager=findViewById(R.id.view);
        viewPager.setAdapter(new MyViewPager(getSupportFragmentManager()));
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                Toast.makeText(Tab_Nav.this, "You selected"+tab.getText().toString(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab)
            {
                Toast.makeText(Tab_Nav.this, "You UnSelected"+tab.getText().toString(), Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab)
            {
                Toast.makeText(Tab_Nav.this, "You ReSelected"+tab.getText().toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    public class MyViewPager extends FragmentPagerAdapter
    {
            String aa[]={"Chats","Status","Calls"};
        public MyViewPager(FragmentManager fm)
        {
            super(fm);
        }

        @Override
        public Fragment getItem(int position)
        {
            if (position==0)
            {
                return  new ChatFragment();

            }
            if (position==1)
            {
                return  new CallsFragment();

            }
            if (position==2)
            {
                return  new StatusFragment();

            }
            return null;
        }

        @Override
        public int getCount() {
            return aa.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return aa[position];
        }
    }
}
