package in.ac.khitguntur.phase1_praticals;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Muni on 29-01-2018.
 */

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>
{
    Context ctx;
    String ti[];
    String subt[];
    int imgee[];
    public MyAdapter(Rec_Activity rec_activity, String[] title,
                     String[] sub_title, int[] image) {
    this.ctx=rec_activity;
    this.imgee=image;
    this.ti=title;
    this.subt=sub_title;


    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view= LayoutInflater.from(ctx).
                inflate(R.layout.data_set,
                        parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position)
    {
        holder.imageView.setImageResource(imgee[position]);
        holder.textView1.setText(ti[position]);
        holder.textView22.setText(subt[position]);
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ctx, ""+ti[position], Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return imgee.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        ImageView imageView;
        TextView textView1,textView22;
        LinearLayout linearLayout;
        public ViewHolder(View itemView)
        {
            super(itemView);
            imageView=itemView.findViewById(R.id.img);
            textView1=itemView.findViewById(R.id.title1);
            textView22=itemView.findViewById(R.id.subtile1);
            linearLayout = itemView.findViewById(R.id.linearL);
        }
    }
}
