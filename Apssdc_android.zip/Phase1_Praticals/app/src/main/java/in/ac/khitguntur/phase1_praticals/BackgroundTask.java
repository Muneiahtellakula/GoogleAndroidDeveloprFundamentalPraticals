package in.ac.khitguntur.phase1_praticals;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Muneiah Tellakula on 11-05-2018.
 */

class BackgroundTask  extends AsyncTask<String,Void,String>
{
    public  static final String Base_url="https://www.googleapis.com/books/v1/volumes?";
    public static final String Query="q";
    public static final String ptintTypr="all";
    public static final String Maxresults="10";
    TextView tittle,author,dec;
    ImageView img;
    Context context;
    public BackgroundTask(MyAsncTask myAsncTask, TextView ti,
                          TextView au, TextView de, ImageView iv) {
    this.context=myAsncTask;
    this.tittle=ti;
    this.author=au;
    this.dec=de;
    this.img=iv;

    }

    @Override
    protected String doInBackground(String... strings)
    {
        Uri uri=Uri.parse(Base_url).buildUpon()
                .appendQueryParameter(ptintTypr,"book")
                .appendQueryParameter(Maxresults,"10")
                .appendQueryParameter(Query,"q").build();
        try {
            URL url=new URL(uri.toString());
            HttpURLConnection httpURLConnection= (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.connect();
            InputStream inputStream=httpURLConnection.getInputStream();
            BufferedReader bufferedReader=new BufferedReader(new
                    InputStreamReader(inputStream));
            StringBuffer stringBuffer=new StringBuffer();
            String line="";
            while ((line=bufferedReader.readLine())!=null){
                stringBuffer.append("\n"+line);
            }
            String re=stringBuffer.toString();
            return  re;

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String s)
    {
        try {
            JSONObject rootObj=new JSONObject(s);
            JSONArray item=rootObj.getJSONArray("items");
            JSONObject itemobj=item.getJSONObject(0);
            JSONObject  volumeinfo=itemobj.getJSONObject("volumeInfo");
            String title=volumeinfo.getString("title");
            tittle.setText(title);
            JSONArray aut=volumeinfo.getJSONArray("authors");
            String a=aut.getString(0);
            author.setText(a);
            //JSONObject description=volumeinfo.getJSONObject("description");
            String d=volumeinfo.getString("description");
            dec.setText(d);
            JSONObject im=volumeinfo.getJSONObject("imageLinks");
            String img1=im.getString("thumbnail");
            Picasso.with(context).load(img1).into(img);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        super.onPostExecute(s);
    }
}
