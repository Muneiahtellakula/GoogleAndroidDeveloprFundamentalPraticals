package in.ac.khitguntur.phase1_praticals;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SharedPref extends AppCompatActivity {
EditText name,pwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_pref);
        name=findViewById(R.id.name_of_user);
        pwd=findViewById(R.id.pwd_of_user);

    }

    public void submit_values(View view)
    {
        String u=name.getText().toString();
        String p=pwd.getText().toString();
        Toast.makeText(this, ""+u+"\n"+p, Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences sharedPreferences=getSharedPreferences("muni",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString("uname",name.getText().toString());
        editor.putString("upass",pwd.getText().toString());
        editor.commit();

    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences sharedPreferences=getSharedPreferences("muni",MODE_PRIVATE);
        String ss=sharedPreferences.getString("uname","");
        String pp=sharedPreferences.getString("upass","");
        name.setText(ss);
        pwd.setText(pp);
    }
}
