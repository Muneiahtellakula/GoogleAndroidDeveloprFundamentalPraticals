package in.ac.khitguntur.phase1_praticals;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MyAlarmActivity extends AppCompatActivity {
    public static final String CUSTOM_BROADCAST="in.ac.khitguntur.phase1_praticals.CUSTOM_BROAD";
AlarmManager alarmManager;
PendingIntent pendingIntent;
JobScheduler jobScheduler;
ComponentName componentName;
Intent intent;
ToggleButton toggleButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_alarm);
        toggleButton=findViewById(R.id.tg11);
        jobScheduler= (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
        componentName=new ComponentName(getPackageName(),
                MyJobService.class.getName());
        alarmManager= (AlarmManager) getSystemService(ALARM_SERVICE);
        intent =new Intent(CUSTOM_BROADCAST);
    pendingIntent=PendingIntent.getBroadcast(MyAlarmActivity.this,11,intent,PendingIntent.FLAG_UPDATE_CURRENT);
    toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton compoundButton, boolean b)
        {
            if (b){
                long triggertime= SystemClock.elapsedRealtime()+1*60*1000;
                long interveltime=1*60*1000;
                alarmManager.setInexactRepeating(AlarmManager
                        .ELAPSED_REALTIME_WAKEUP,triggertime,interveltime,pendingIntent);
                Toast.makeText(MyAlarmActivity.this, "Alarm On", Toast.LENGTH_SHORT).show();
            }
            else
                {
                    alarmManager.cancel(pendingIntent);
                    Toast.makeText(MyAlarmActivity.this, "Alarm Off", Toast.LENGTH_SHORT).show();

            }

        }
    });
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void sedule_job(View view)
    {
        JobInfo.Builder builder=new JobInfo.Builder(8,componentName);
        builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
        builder.setRequiresCharging(true);
        JobInfo jobInfo=builder.build();
        jobScheduler.schedule(jobInfo);
    }
}
