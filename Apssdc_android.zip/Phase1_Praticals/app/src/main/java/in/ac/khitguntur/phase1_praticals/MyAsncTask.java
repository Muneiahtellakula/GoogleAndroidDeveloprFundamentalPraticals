package in.ac.khitguntur.phase1_praticals;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MyAsncTask extends AppCompatActivity {
        EditText et;
        TextView ti,au,de;
        BackgroundTask backgroundTask;
        ImageView iv;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_asnc_task);
        et=findViewById(R.id.bname);
        au=findViewById(R.id.author_book);
        de=findViewById(R.id.descr_book);
        ti=findViewById(R.id.title_book);
        iv=findViewById(R.id.imageView);


    }

    public void search(View view) {
        String a=et.getText().toString();
        backgroundTask=new BackgroundTask(this,ti,au,de,iv);
        backgroundTask.execute(a);
    }
}
