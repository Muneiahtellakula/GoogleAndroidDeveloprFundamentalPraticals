package in.ac.khitguntur.phase1_praticals;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity
{
AlertDialog alertDialog;
RecyclerView recyclerView;
    private String title[];
    private String sub_title[];
    int image[];
    RecyclerAdapter adapter;
    LinearLayout layout;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recyclerview);
        layout=findViewById(R.id.li);
        title=getResources().getStringArray(R.array.android);
        sub_title=getResources().getStringArray(R.array.android_sub);
        image= new int[]{R.drawable.cupcake,R.drawable.donut,
                R.drawable.eclair,R.drawable.froyo,
                R.drawable.ss,
                R.drawable.honeycomb,
                R.drawable.ice,R.drawable.jelly_bean,
                R.drawable.kitkat,R.drawable.lollipop,
                R.drawable.marsmellow,R.drawable.nougat,
                R.drawable.oreo};
                adapter=new RecyclerAdapter(this,title,sub_title,image);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new
                LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false));

    }

}


