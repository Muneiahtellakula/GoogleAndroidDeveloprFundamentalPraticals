package in.ac.khitguntur.phase1_praticals;

import android.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class UserInputControls extends AppCompatActivity
{
    EditText uname,umaobile,uemail;
    TextView textt;
    RadioGroup radioGroup;
    RadioButton m,f;
    CheckBox j,p,cc;
    SeekBar seekBar;
    Spinner spinner;
    Switch aSwitch;
    String gender="";
    String languge="";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_input_controls);
        uname=findViewById(R.id.name);
        umaobile=findViewById(R.id.mobile);
        uemail=findViewById(R.id.email);
        textt=findViewById(R.id.textv);
        radioGroup=findViewById(R.id.rg);
        j=findViewById(R.id.java);
        p=findViewById(R.id.python);
        m=findViewById(R.id.male);
        f=findViewById(R.id.female);
        cc=findViewById(R.id.c);
        spinner=findViewById(R.id.sp);
       // String d[]={"CSE","ECE","MECH","IT"};
      //ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(android.R.layout.simple_dropdown_item_1line,);

        seekBar=findViewById(R.id.see);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
         int userProgress=0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b)
            {
                userProgress=i;

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar)
            {
//               seekBar.setProgress(userProgress);
//                Toast.makeText(UserInputControls.this, ""+userProgress, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                seekBar.setProgress(userProgress);
                Toast.makeText(UserInputControls.this, ""+userProgress, Toast.LENGTH_SHORT).show();
            }
        });
        aSwitch=findViewById(R.id.swi);
        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    Toast.makeText(UserInputControls.this, "On State", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(UserInputControls.this, "off State", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void show_details(View view)
    {
        String s_uname=uname.getText().toString();
        String s_email=uemail.getText().toString();
        String s_umobile=umaobile.getText().toString();
        String s_branch=spinner.getSelectedItem().toString();
        if (s_uname.isEmpty()&&s_email.isEmpty()&&s_umobile.isEmpty()
                &&gender.isEmpty()&&languge.isEmpty()){
            Toast.makeText(this, "Please fill the details ..!", Toast.LENGTH_SHORT).show();
        }else {
            if (f.isChecked()) {
                gender = "female";

            } else if (m.isChecked())
            {
                gender = "male";
            }
            if (j.isChecked()) {
                languge = "Java" + "\n";
            }
            if (p.isChecked()) {
                languge = languge + "Python" + "\n";
            }
            if (cc.isChecked()) {
                languge = languge + "C" + "\n";
            }
        }

            textt.setText("User name:" + s_uname + "\n" +
                    "Email:" + s_email + "\n" +
                    "Mobile num:" + s_umobile + "\n" +

                    "Branch-" + s_branch + "\n" + "Gender-" + gender + "\n" + "Known Lanuge-" + languge);
                    uemail.setText("");
                    umaobile.setText("");
                    uemail.setText("");
                    uname.setText("");




    }

    public void opentime(View view)
    {
        DialogFragment newFragment = new TimePickerFragment();
        newFragment.show(getFragmentManager(),
                getString(R.string.time_picker));
    }


    public void datepicker(View view)
    {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getFragmentManager(),
                getString(R.string.date_picker));
    }
/*
    public void datepicker(int year, int month, int day) {
        // The month integer returned by the date picker starts counting at 0
        // for January, so you need to add 1 to show months starting at 1.
        String month_string = Integer.toString(month + 1);
        String day_string = Integer.toString(day);
        String year_string = Integer.toString(year);
        // Assign the concatenated strings to dateMessage.
        String dateMessage = (month_string + "/" + day_string + "/" + year_string);
        Toast.makeText(this, getString(R.string.date) + dateMessage, Toast.LENGTH_SHORT).show();
    }

    *//*public void opentime(View view)
    {
        String hour_string = Integer.toString(hourOfDay);
        String minute_string = Integer.toString(minute);
        // Assign the concatenated strings to timeMessage.
        String timeMessage = (hour_string + ":" + minute_string);
        Toast.makeText(this, getString(R.string.time) + timeMessage, Toast.LENGTH_SHORT).show();
    }*//*

    public void opentime(int hourOfDay, int minute) {
        // Convert time elements into strings.
        String hour_string = Integer.toString(hourOfDay);
        String minute_string = Integer.toString(minute);
        // Assign the concatenated strings to timeMessage.
        String timeMessage = (hour_string + ":" + minute_string);
        Toast.makeText(this, getString(R.string.time) + timeMessage, Toast.LENGTH_SHORT).show();
    }*/

/*    public void processDatePickerResult( int hourOfDay, int minute) {


        String hour_string = Integer.toString(hourOfDay);
        String minute_string = Integer.toString(minute);
        // Assign the concatenated strings to timeMessage.
        String timeMessage = (hour_string + ":" + minute_string);
        Toast.makeText(this, getString(R.string.time) + timeMessage, Toast.LENGTH_SHORT).show();
    }*/
}
