package in.ac.khitguntur.phase1_praticals;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MyBroadCasrReceiver extends BroadcastReceiver
{
    public static final String CUSTOM_BROADCAT=
            "in.ac.khitguntur.phase1_praticals.CUSTOM_BROADCAST";

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        String action=intent.getAction();
        switch (action)
        {
            case Intent.ACTION_AIRPLANE_MODE_CHANGED:
                Toast.makeText(context, "ACTION_AIRPLANE_MODE_CHANGED", Toast.LENGTH_SHORT).show();
                break;
            case Intent.ACTION_POWER_CONNECTED:
                Toast.makeText(context, "ACTION_POWER_CONNECTED", Toast.LENGTH_SHORT).show();
                break;
            case Intent.ACTION_POWER_DISCONNECTED:
                Toast.makeText(context, "ACTION_POWER_DISCONNECTED", Toast.LENGTH_SHORT).show();
                break;
            case CUSTOM_BROADCAT:
                Toast.makeText(context, "Hi Custom Recever", Toast.LENGTH_SHORT).show();
                break;
        }

    }
}
