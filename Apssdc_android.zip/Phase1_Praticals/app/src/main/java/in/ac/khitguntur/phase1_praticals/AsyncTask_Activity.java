package in.ac.khitguntur.phase1_praticals;


import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import it.sephiroth.android.library.picasso.Picasso;


public class AsyncTask_Activity extends AppCompatActivity
        implements LoaderManager.LoaderCallbacks<String>
{
    EditText editText;
    TextView titleText,authorText,desc;
    ImageView im;
    ProgressBar pb;
    MyProgressTask myProgressTask;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_async_task);
        desc = findViewById(R.id.descr);
        editText = findViewById(R.id.booksText);
        titleText = findViewById(R.id.titleHolder);
        authorText = findViewById(R.id.authorHolder);
        im=findViewById(R.id.imagesss);
        pb = findViewById(R.id.progressBar);
        pb.setVisibility(View.GONE);

        if(getSupportLoaderManager().getLoader(0)!=null)
        {
            getSupportLoaderManager().initLoader(0,
                    null,this);
        }

    }

    public void searchBooks(View view) {
        String bookSearched = editText.getText().toString();
        Bundle bundle = new Bundle();
        bundle.putString("queryBook", bookSearched);
        getSupportLoaderManager().restartLoader(0, bundle,
                this);
        pb.setVisibility(View.VISIBLE);
       /* myProgressTask=new MyProgressTask(this);
        myProgressTask.execute();*/

    }
    @Override
    public Loader<String> onCreateLoader(int id, Bundle args)
    {
        return new FetchBooksLoader(this,
                args.getString("queryBook"));
    }

    @Override
    public void onLoadFinished(Loader<String> loader, String data)
    {
        try {
            pb.setVisibility(View.GONE);
            JSONObject rootObject = new JSONObject(data);
            JSONArray itemsArray = rootObject.getJSONArray("items");
            JSONObject item1Object = itemsArray.getJSONObject(0);
            JSONObject volObj = item1Object.getJSONObject("volumeInfo");
            String titles = volObj.getString("title");
            JSONArray authors = volObj.getJSONArray("authors");
            String authorss = authors.getString(0);
            titleText.setText("TITLE : "+titles);
            String des=volObj.getString("description");
            Toast.makeText(this, ""+des, Toast.LENGTH_SHORT).show();
            JSONObject image = volObj.getJSONObject("imageLinks");
            String link = image.getString("thumbnail");
            authorText.setText("Author is: "+authorss);
            Picasso.with(this).load(link).into(im);
            /*JSONObject descObj=rootObject.getJSONObject("description");
            desc.setText("Description :"+descObj);
*/
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

    }

    @Override
    public void onLoaderReset(Loader<String> loader) {

    }
}

