package in.ac.khitguntur.phase1_praticals;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by Hi on 04-08-2017.
 */

public class MyProgressTask extends AsyncTask<Void,Integer,String>
{
    Context context;
    ProgressDialog progressDialog;
    public MyProgressTask(Context ct){
        context=ct;

    }

    @Override
    protected String doInBackground(Void... voids) {
        try{
            for (int i=0;i<=10;i++){
                Thread.sleep(250);
                Log.i("Thread","excute"+i);
                publishProgress(i);

            }
            return  "Successfully";
        }catch (Exception e){
            Log.i("Exception",e.getMessage());
            return "failure";
        }
    }

    @Override
    protected void onPreExecute() {
        // super.onPreExecute();
        progressDialog =new ProgressDialog(context);
        progressDialog.setTitle("Downloading");
        progressDialog.setMessage("Please wait...");
        progressDialog.setMax(10);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setButton(ProgressDialog.BUTTON_NEGATIVE, "Cancel",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                        cancel(true);
                    }
                });
        progressDialog.show();
    }



    @Override
    protected void onPostExecute(String s) {
        //super.onPostExecute(s);
        Toast.makeText(context,s,Toast.LENGTH_SHORT).show();
        progressDialog.dismiss();

    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        //super.onProgressUpdate(values);
        int myvalue=values[0];
        progressDialog.setProgress(myvalue);


    }
}

