package in.ac.khitguntur.phase1_praticals;

import android.content.Context;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Hello_Toast extends AppCompatActivity
{
    TextView textView;
    int count=0;
    Context context;
    public static final String SavedState="value";



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hello__toast);
        textView=findViewById(R.id.he1);
        if (savedInstanceState!=null){
            textView.setText(savedInstanceState.getString(SavedState));
        }
    }

    public void increase_count(View view)
    {
        count++;
        textView.setText(""+count);
    }

    public void display_toast(View view)
    {
        Toast.makeText(this, "Count is :"+textView.getText().toString(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(SavedState,textView.getText().toString());
    }
}
