package in.ac.khitguntur.phase1_praticals;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Muneiah Tellakula on 22-05-2018.
 */

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {
    Context context;
    String tv[],tv2[];
    int img[];
    RecyclerView re;

    public RecyclerAdapter(MainActivity mainActivity, String[]
            title, String[] sub_title, int[] image) {
        this.context=mainActivity;
        this.img=image;
        this.tv=title;
        this.tv2=sub_title;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent,
                                           int viewType)
    {
        View view= LayoutInflater.from(context).inflate(R.layout.my_row_data,parent,false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
            //holder.
        holder.i.setImageResource(img[position]);
        holder.t.setText(tv[position]);
        holder.tt.setText(tv2[position]);
      //  holder.linearLayout.setOnClickListener(new View.OnClickListener() {
           // @Override
          //  public void onClick(View v) {
             /* Intent intent=new Intent(context,Hello_Toast.class);
                context.startActivity(intent);*/
              /*  Toast.makeText(context, ""+tv[position], Toast.LENGTH_SHORT).show();*/
               /* switch (position) {
                    case 0:
                       // new Hello_Toast();
                        break;
                    case 1:
                        new Two_Activity();
                        break;
                    case 3:
                        new AsyncTask_Activity();
                        break;
                    case 4:
                        new LifeCycleActivity();
                        break;
                }*/
              /*
              AlertDialog alertDialog;
                alertDialog = new AlertDialog.Builder(context).create();

                alertDialog.setTitle("Make Your First Interactive UI");

                alertDialog.setMessage("APP OverView: \n The \"Hello Toast\" app will consist of two buttons and one text view. When you click on the first button, it will display a short message, or toast, on the screen. Clicking on the second button will increase a click counter; the total count of mouse clicks will be displayed in the text view.\n" +
                        "\"Here's what the finished app will look like:");

                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, " Practicals", new DialogInterface.OnClickListener()
                {

                    public void onClick(DialogInterface dialog, int id)
                    {
                        String url="https://google-developer-training.gitbooks.io/android-developer-fundamentals-course-practicals/content/en/Unit%201/12_p_make_your_first_interactive_ui.html";

                        Intent i = new Intent(context, MyWebViewActivity.class);
                       context.startActivity(i);

                    } });
                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open APP", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int id) {
                        Intent intent=new Intent(context,Hello_Toast.class);
                      context.startActivity(intent);
                    }});
                alertDialog.show();*/
           // }
       // });
    }

    @Override
    public int getItemCount() {
        return img.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView t,tt;
        ImageView i;
        LinearLayout linearLayout;
//        RecyclerView recView;
        public MyViewHolder(View itemView) {
            super(itemView);
          //  recView=itemView.findViewById(R.id.recyclerview);
            t=itemView.findViewById(R.id.txt);
            tt=itemView.findViewById(R.id.sub_text);
            i=itemView.findViewById(R.id.img_rec);
           // linearLayout=itemView.findViewById(R.id.li);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    switch (getAdapterPosition()){
                        case 0:
                           Intent intent1=new Intent(context,Hello_Toast.class);
                           context.startActivity(intent1);
                            break;
                        case 1:
                            Intent intent2=new Intent(context,Two_Activity.class);
                            context.startActivity(intent2);
                            break;
                        case 2:
                            Intent intent3=new Intent(context,Scrolling_Text.class);
                            context.startActivity(intent3);
                            break;
                        case 3:
                            Intent intent3_intent=new Intent(context,ImplecityIntents.class);
                            context.startActivity(intent3_intent);
                            break;
                        case 4:
                            Intent intent5=new Intent(context,LifeCycleActivity.class);
                            context.startActivity(intent5);
                            break;
                        case 5:
                            Intent intent7=new Intent(context,Menu_Items.class);
                            context.startActivity(intent7);
                            break;

                        case 6:
                            Intent intent0=new Intent(context,Tab_Nav.class);
                            context.startActivity(intent0);
                            break;
                        case 7:
                            Intent intent4=new Intent(context,Rec_Activity.class);
                            context.startActivity(intent4);
                            break;
                        /*case 8:
                            Intent intent8=new Intent(context,Tab_Nav.class);
                            context.startActivity(intent8);
                            break;*/
                        case 8:
                            Intent intent9=new Intent(context,AsyncTask_Activity.class);
                            context.startActivity(intent9);
                            break;
                        case 9:
                            Intent intent6=new Intent(context,UserInputControls.class);
                            context.startActivity(intent6);
                            break;
                        case 10:
                            Intent intent10=new Intent(context,MyAlarmActivity.class);
                            context.startActivity(intent10);
                            break;
                        case 11:
                            Intent intent11=new Intent(context,SharedPref.class);
                            context.startActivity(intent11);
                            break;
                        case 12:
                            Intent intent12=new Intent(context,DBActivity.class);
                            context.startActivity(intent12);
                            break;
                        /*case 13:
                            Intent intent13=new Intent(context,DBActivity.class);
                            context.startActivity(intent13);
                            break;*/

                    }
                }
            });
        }
    }
}
