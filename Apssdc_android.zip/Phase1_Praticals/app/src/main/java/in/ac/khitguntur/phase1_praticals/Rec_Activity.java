package in.ac.khitguntur.phase1_praticals;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class Rec_Activity extends AppCompatActivity
{
    RecyclerView recyclerView;
    private String title[];
    private String sub_title[];
    int image[];

  MyAdapter myAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rec_);
        recyclerView=findViewById(R.id.rec1);
        title=getResources().getStringArray(R.array.android_titles);
        sub_title=getResources().getStringArray(R.array.android_sub_titles);
        image= new int[]{R.drawable.cupcake,R.drawable.donut,
                R.drawable.eclair,R.drawable.froyo,
                R.drawable.ss,
                R.drawable.honeycomb,
                R.drawable.ice,R.drawable.jelly_bean,
                R.drawable.kitkat,R.drawable.lollipop,
                R.drawable.marsmellow,R.drawable.nougat,
                R.drawable.oreo};
        /*image= new int[]{R.drawable.gingerbread,
                R.drawable.gingerbread, R.drawable.gingerbread,
                R.drawable.gingerbread, R.drawable.gingerbread,
                R.drawable.gingerbread,R.drawable.gingerbread,
                R.drawable.gingerbread,R.drawable.gingerbread,
                R.drawable.gingerbread,R.drawable.gingerbread,
                R.drawable.gingerbread,R.drawable.gingerbread,
                };
*/
        myAdapter=new MyAdapter(this,title,sub_title,image);
        recyclerView.setAdapter(myAdapter);
        recyclerView.setLayoutManager(new
                LinearLayoutManager(this));

    }
}
