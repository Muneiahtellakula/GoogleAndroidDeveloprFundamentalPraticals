package in.ac.khitguntur.phase1_praticals;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Spinner;

public class MyWebViewActivity extends AppCompatActivity {
Spinner sp;
WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_web_view);
        sp=findViewById(R.id.spinner1);
        webView=findViewById(R.id.web);

    }

    public void practicals(View view)
    {
        String name= sp.getSelectedItem().toString();
        webView.loadUrl(name);
       // webView.getSettings().getBuiltInZoomControls();

    }
}
