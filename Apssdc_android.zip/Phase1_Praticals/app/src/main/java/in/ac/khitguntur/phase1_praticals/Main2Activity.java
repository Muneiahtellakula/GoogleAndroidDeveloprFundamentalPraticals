package in.ac.khitguntur.phase1_praticals;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class Main2Activity extends AppCompatActivity {

    AlertDialog alertDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }
    public void rise_hello_toast(View view)
    {

        alertDialog = new AlertDialog.Builder(this).create();

        alertDialog.setTitle("Make Your First Interactive UI");

        alertDialog.setMessage("APP OverView: \n The \"Hello Toast\" app will consist of two buttons and one text view. When you click on the first button, it will display a short message, or toast, on the screen. Clicking on the second button will increase a click counter; the total count of mouse clicks will be displayed in the text view.\n" +
                "\"Here's what the finished app will look like:");

        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, " Practicals", new DialogInterface.OnClickListener()
        {

            public void onClick(DialogInterface dialog, int id)
            {
                String url="https://google-developer-training.gitbooks.io/android-developer-fundamentals-course-practicals/content/en/Unit%201/12_p_make_your_first_interactive_ui.html";

                Intent i = new Intent(getApplicationContext(), MyWebViewActivity.class);
                startActivity(i);

            } });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open APP", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {
                Intent intent=new Intent(getApplicationContext(),Hello_Toast.class);
                startActivity(intent);
            }});
        alertDialog.show();
    }
    public void scroll_view(View view) {
        alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Working with TextView Elements ");
        alertDialog.setMessage("App OverView..!\nThe Scrolling Text app demonstrates the ScrollView UI component.");
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, " Practicals", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {
                String url = "https://google-developer-training.gitbooks.io/android-developer-fundamentals-course-practicals/content/en/Unit%201/13_p_working_with_textview_elements.html";
                Uri webpage = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    Log.d("ImplicitIntents", "Can't handle this intent!");
                }

            }
        });

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {
                Intent i=new Intent(getApplication(),Scrolling_Text.class);
                startActivity(i);
            }});
        alertDialog.show();
    }

    public void two_Activitys(View view)
    {

        alertDialog = new AlertDialog.Builder(this).create();

        alertDialog.setTitle("Create and Start Activities");

        alertDialog.setMessage("App Overview \n" +
                "In this you will create and build an app called TwoActivities that, unsurprisingly, contains two activities.");

        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, " Practicals", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {
                String url = "https://google-developer-training.gitbooks.io/android-developer-fundamentals-course-practicals/content/en/Unit%201/21_p_create_and_start_activities.html";
                Uri webpage = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    Log.d("ImplicitIntents", "Can't handle this intent!");
                }
            }
        });

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                Intent intent=new Intent(getApplication(),Two_Activity.class);
                startActivity(intent);
            }});
        alertDialog.show();
    }
    public void life_cycle(View view)
    {
        alertDialog = new AlertDialog.Builder(this).create();

        alertDialog.setTitle(" Activity Lifecycle and Instance State");

        alertDialog.setMessage("The activity lifecycle is the set of states an activity can be in during its entire lifetime, from the time it is initially created to when it is destroyed and the system reclaims that activity's resources. As a user navigates between activities in your app (as well as into and out of your app), those activities each transition between different states in the activity lifecycle.");

        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, " Pracical", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {
                String url = "https://google-developer-training.gitbooks.io/android-developer-fundamentals-course-practicals/content/en/Unit%201/22_p_activity_lifecycle_&_state.html";
                Uri webpage = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    Log.d("ImplicitIntents", "Can't handle this intent!");
                }
            }
        });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                Intent intent=new Intent(getApplicationContext(),LifeCycleActivity.class);
                startActivity(intent);


            }});

        alertDialog.show();

    }

    public void open_implecity(View view)
    {

        alertDialog = new AlertDialog.Builder(this).create();

        alertDialog.setTitle("Start Activities with Implicit Intents");

        alertDialog.setMessage("A new app with one activity and three options for actions: open a web site, open a location on a map, and share a snippet of text. \n All of the text fields are editable (EditText), but contain default values");

        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, " Practical", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {
                String url = "https://google-developer-training.gitbooks.io/android-developer-fundamentals-course-practicals/content/en/Unit%201/23_p_activities_and_implicit_intents.html";
                Uri webpage = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    Log.d("ImplicitIntents", "Can't handle this intent!");
                }


            } });

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                Intent intent=new Intent(getApplicationContext(),ImplecityIntents.class);
                startActivity(intent);

            }});

        alertDialog.show();
    }

    public void open_Drawable(View view)
    {

        alertDialog = new AlertDialog.Builder(this).create();

        alertDialog.setTitle("6.Hello Compact");

        alertDialog.setMessage("create an app called HelloCompat with one textview that displays Hello World on the screen, and one button, that changes the color of the text. There are 20 possible colors, defined as resources in the color.xml file, and\n" +
                "each button click randomly picks one of those colors.");

        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Close", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                //...

            } });

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open Practical", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                Intent intent=new Intent(getApplicationContext(),HelloCompact.class);
                startActivity(intent);


            }});

        alertDialog.show();
    }

    public void userControls(View view)
    {
        alertDialog = new AlertDialog.Builder(this).create();

        alertDialog.setTitle("7.Using Keyboards, Input Controls, Alerts, and Pickers");

        alertDialog.setMessage("create an app \n1.Button\n2.EditText\n3.spinner\n4.Radio Button \n5.Check Box \n6.SeekBar \n7.Switch Button");


        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "GitBook Practical", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {


                String url = " https://google-developer-training.gitbooks.io/android-developer-fundamentals-course-practicals/content/en/Unit%202/41_p_use_keyboards,_input_controls,_alerts,_and_pi.html";
                Uri webpage = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    Log.d("ImplicitIntents", "Can't handle this intent!");
                }

            } });

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                Intent intent=new Intent(getApplicationContext(),UserInputControls.class);
                startActivity(intent);
            }});

        alertDialog.show();
    }

    public void open_menu_activity(View view)
    {
        alertDialog = new AlertDialog.Builder(this).create();

        alertDialog.setTitle("7.Menu Items");

        alertDialog.setMessage("APP OVERVIEW \n1.Options Menu\n 2.Context menu");


        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Practicals", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                String url = " https://google-developer-training.gitbooks.io/android-developer-fundamentals-course-practicals/content/en/Unit%202/41_p_use_keyboards,_input_controls,_alerts,_and_pi.html";
                Uri webpage = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    Log.d("ImplicitIntents", "Can't handle this intent!");
                }


            } });

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                Intent intent=new Intent(getApplicationContext(),Menu_Items.class);
                startActivity(intent);


            }});

        alertDialog.show();
    }

    public void open_tabNav(View view)
    {
        alertDialog = new AlertDialog.Builder(this).create();

        alertDialog.setTitle("7.Menu Items");

        alertDialog.setMessage("APP OVERVIEW \n1.Options Menu\n 2.Context menu");


        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Practical", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {
                String url = " https://google-developer-training.gitbooks.io/android-developer-fundamentals-course-practicals/content/en/Unit%202/41_p_use_keyboards,_input_controls,_alerts,_and_pi.html";
                Uri webpage = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    Log.d("ImplicitIntents", "Can't handle this intent!");
                }



            } });

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                Intent intent=new Intent(getApplicationContext(),Tab_Nav.class);
                startActivity(intent);


            }});

        alertDialog.show();
    }

    public void open_recyclerView(View view)
    {
        alertDialog = new AlertDialog.Builder(this).create();

        alertDialog.setTitle("10.Recycler View");

        alertDialog.setMessage("APP OVERVIEW \n1.A RecyclerView Is a Functionality of viwing a list of items .");


        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Practical", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                //...

            } });

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                Intent intent=new Intent(getApplicationContext(),Rec_Activity.class);
                startActivity(intent);


            }});

        alertDialog.show();
    }

    public void open_async(View view)
    {
        alertDialog = new AlertDialog.Builder(this).create();

        alertDialog.setTitle("11.Async Task");

        alertDialog.setMessage("APP OVERVIEW \n1.Asynk task forbackground opartions perfoming");


        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Practical", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                //...

            } });

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                Intent intent=new Intent(getApplicationContext(),AsyncTask_Activity.class);
                startActivity(intent);


            }});

        alertDialog.show();
    }

    public void open_alarmTask(View view)
    {
        alertDialog = new AlertDialog.Builder(this).create();

        alertDialog.setTitle("11.Alarm WakeUp");

        alertDialog.setMessage("APP OVERVIEW \n.ALARM SERVICE");


        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Practical", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                //...

            } });

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {

                Intent intent=new Intent(getApplicationContext(),MyAlarmActivity.class);
                startActivity(intent);


            }});

        alertDialog.show();
    }

    public void open_Broadcast(View view)
    {
        alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("12.BroadCast Reciver");
        alertDialog.setMessage("APP OVERVIEW \n1.Asynk task forbackground opartions perfoming");
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Practical",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id)
                    {

                    } });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {
                Intent intent=new Intent(getApplicationContext(),BroadCastReceverActivity.class);
                startActivity(intent);
            }});

        alertDialog.show();
    }

    public void open_ScheduleJob(View view)
    {
        alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("12.BroadCast Reciver");
        alertDialog.setMessage("APP OVERVIEW \n1.Asynk task forbackground opartions perfoming");
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Practical",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id)
                    {

                    } });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {
                Intent intent=new Intent(getApplicationContext(),MyAlarmActivity.class);
                startActivity(intent);
            }});

        alertDialog.show();
    }

    public void open_Sharedpref(View view)
    {
        alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("12.BroadCast Reciver");
        alertDialog.setMessage("APP OVERVIEW \n1.Asynk task forbackground opartions perfoming");
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Practical",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id)
                    {

                    } });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {
                Intent intent=new Intent(getApplicationContext(),SharedPref.class);
                startActivity(intent);
            }});

        alertDialog.show();
    }

    public void openDb(View view)
    {
        alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("12.BroadCast Reciver");
        alertDialog.setMessage("APP OVERVIEW \n1.Asynk task forbackground opartions perfoming");
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Practical",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id)
                    {

                    } });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Open App", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {
                Intent intent=new Intent(getApplicationContext(),DBActivity.class);
                startActivity(intent);
            }});

        alertDialog.show();
    }


    public void asyncTaskActivityLoad(View view)
    {
        Intent i=new Intent(this,MyAsncTask.class);
        startActivity(i);
    }
}
