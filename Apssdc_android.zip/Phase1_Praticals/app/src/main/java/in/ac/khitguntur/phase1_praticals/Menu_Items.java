package in.ac.khitguntur.phase1_praticals;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Menu_Items extends AppCompatActivity
{
TextView textView1,textView2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu__items);
        textView1=findViewById(R.id.tv1);
        textView2=findViewById(R.id.tv2);
        registerForContextMenu(textView1);
        registerForContextMenu(textView2);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.option_menu,menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
         switch (item.getItemId())
         {
             case R.id.android:
                 Toast.makeText(this, "Hello Android Team ", Toast.LENGTH_SHORT).show();
             break;
             case R.id.pwd:
                 Toast.makeText(this, "Hello Progrss Web App Team", Toast.LENGTH_SHORT).show();
                break;
             case R.id.python:
                 Toast.makeText(this, "Hello Python Team", Toast.LENGTH_SHORT).show();
                break;
             case R.id.menu:
                 Toast.makeText(this, "No number ", Toast.LENGTH_SHORT).show();
         }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        switch (v.getId()){
            case R.id.tv1:
                getMenuInflater().inflate(R.menu.contex_menu1,menu);
                break;
            case R.id.tv2:
                getMenuInflater().inflate(R.menu.contex_menu2,menu);
                break;
        }
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.contextmm_item1:
                Toast.makeText(this, "welcome context menu", Toast.LENGTH_SHORT).show();
                break;
            case R.id.contextm_item2:
                Toast.makeText(this, "Welcome to Context Menu I 2", Toast.LENGTH_SHORT).show();
                break;
            case R.id.setting:
                Toast.makeText(this, "Welcome to Contex Menu 2 I 1", Toast.LENGTH_SHORT).show();
                break;
            case R.id.fava:
                Toast.makeText(this, "Welcome to Context Menu 2 I 2", Toast.LENGTH_SHORT).show();
                break;

        }

        return true;
    }
}
